import 'package:flutter/material.dart';

/// Diagnostic version: impossible-to-miss red screen so we can confirm
/// the compile -> run -> render pipeline actually works end to end,
/// before worrying about matching the app's own theme colors.
Widget buildExtension() {
  return Container(
    color: Colors.red,
    child: const Center(
      child: Text(
        'HELLO FROM EXTENSION',
        style: TextStyle(color: Colors.white, fontSize: 24),
      ),
    ),
  );
}
